export const roundLayoutSize = (size: number): number =>
  Math.round(size * 1000) / 1000;
